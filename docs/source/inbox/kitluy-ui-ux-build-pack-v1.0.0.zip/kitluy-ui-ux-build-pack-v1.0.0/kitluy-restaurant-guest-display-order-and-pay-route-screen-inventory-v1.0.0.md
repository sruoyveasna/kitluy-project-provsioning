# KitLuy Restaurant Guest Display and Order-and-Pay Route and Screen Inventory

| Field | Value |
|---|---|
| Filename | `kitluy-restaurant-guest-display-order-and-pay-route-screen-inventory-v1.0.0.md` |
| Version | `v1.0.0` |
| Date | 2026-07-26 |
| Owner | HET / KitLuy Suite Project Owner |
| Status | Preliminary phase-gated route contract; not an approved detailed product specification |
| Primary market | Cambodia |
| Languages | Khmer (`km-KH`) and English (`en-KH`) |
| Currencies | KHR and USD |
| Timezone | `Asia/Phnom_Penh` |

> **Evidence rule:** This artifact defines a build contract. It is not evidence that Figma files, components, routes, code, migrations, tests or deployments exist. Every missing owner, brand, provider or production value is marked `[REQUIRED: ...]`.

## Authority and scope

Authority order:

1. Current owner decisions and KitLuy Project Instructions.
2. Applied migrations, verified code/tests and production evidence.
3. Current approved KitLuy Rebuild, Business and product specifications.
4. This UI/UX build-pack artifact after approval.
5. Approved handoffs and evidence-based analyses.
6. Competitor rebuild documents as design references only.

The shared design system is neutral. Laundry terminology belongs only in Laundry-specific compositions and must not be hardcoded into Core components.

## Phase gate

This inventory exists to prevent the application from being omitted from the shared UI/UX pack. It does **not** approve the detailed workflow, schema, state machine, permissions or API contracts. All routes remain hidden and disabled until the Phase product specification, vertical delta, permissions, offline behavior, hardware profile, QA matrix and owner approval exist.

## Figma file registry

| Field | Value |
|---|---|
| Product Figma URL | `[REQUIRED: KitLuy Restaurant Guest Display and Order-and-Pay Route and Screen Inventory Figma URL]` |
| Figma file key | `[REQUIRED: file_key]` |
| Design-system library | `[REQUIRED: KitLuy Design System Figma URL]` |
| Screen page | `[REQUIRED: page node-id]` |
| Review status | Not supplied; do not claim Designed/Approved |

## Mapping conventions

- `KLUI-GUEST-NNN` is a stable UI-pack traceability ID, not a replacement for `KLMF-*` or product feature IDs.
- Permission names are contract requirements; exact registry keys must be reconciled with the canonical RBAC permission registry.
- Data-contract names are families until exact OpenAPI/JSON Schema operation IDs are published.
- Every route implements the canonical state model and must not present stale, partial, cached or unavailable data as authoritative.
- Analytics events never include raw PII, free text, payment tokens or secrets.

## Route and screen inventory

| Route | Screen ID | Screen | Feature IDs | Permission | Data contracts | Mutations | Components | States | Localization keys | Analytics events | QA cases | Figma reference |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `/display/idle` | `GUEST-SCR-001` | Display / Idle | `KLUI-GUEST-001` | `restaurant.guest_display.use` | Commerce Store/customer-session read contract `restaurant_guest.display.idle`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.display.idle.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.display_idle`); `ui.primary_action` when used; no raw PII | `QA-GUEST-001-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-001` / `[REQUIRED: node-id]` |
| `/display/check/:checkId` | `GUEST-SCR-002` | Display / Check / Check detail | `KLUI-GUEST-002` | `restaurant.guest_display.use` | Commerce Store/customer-session read contract `restaurant_guest.display.check.detail`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.display.check.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.display_check_detail`); `ui.primary_action` when used; no raw PII | `QA-GUEST-002-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-002` / `[REQUIRED: node-id]` |
| `/display/payment` | `GUEST-SCR-003` | Display / Payment | `KLUI-GUEST-003` | `restaurant.guest_display.use` | Commerce Store/customer-session read contract `restaurant_guest.display.payment`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.display.payment.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.display_payment`); `ui.primary_action` when used; no raw PII | `QA-GUEST-003-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-003` / `[REQUIRED: node-id]` |
| `/display/receipt` | `GUEST-SCR-004` | Display / Receipt | `KLUI-GUEST-004` | `restaurant.guest_display.use` | Commerce Store/customer-session read contract `restaurant_guest.display.receipt`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.display.receipt.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.display_receipt`); `ui.primary_action` when used; no raw PII | `QA-GUEST-004-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-004` / `[REQUIRED: node-id]` |
| `/qr/:locationSlug` | `GUEST-SCR-005` | Qr / Detail | `KLUI-GUEST-005` | `public` | Commerce Store/customer-session read contract `restaurant_guest.qr.detail`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.qr.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.qr_detail`); `ui.primary_action` when used; no raw PII | `QA-GUEST-005-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-005` / `[REQUIRED: node-id]` |
| `/menu` | `GUEST-SCR-006` | Menu | `KLUI-GUEST-006` | `public` | Commerce Store/customer-session read contract `restaurant_guest.menu`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.menu.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.menu`); `ui.primary_action` when used; no raw PII | `QA-GUEST-006-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-006` / `[REQUIRED: node-id]` |
| `/menu/item/:itemId` | `GUEST-SCR-007` | Menu / Item / Item detail | `KLUI-GUEST-007` | `public` | Commerce Store/customer-session read contract `restaurant_guest.menu.item.detail`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.menu.item.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.menu_item_detail`); `ui.primary_action` when used; no raw PII | `QA-GUEST-007-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-007` / `[REQUIRED: node-id]` |
| `/cart` | `GUEST-SCR-008` | Cart | `KLUI-GUEST-008` | `customer.cart.own` | Commerce Store/customer-session read contract `restaurant_guest.cart`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.cart.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.cart`); `ui.primary_action` when used; no raw PII | `QA-GUEST-008-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-008` / `[REQUIRED: node-id]` |
| `/checkout` | `GUEST-SCR-009` | Checkout | `KLUI-GUEST-009` | `customer.checkout.own` | Commerce Store/customer-session read contract `restaurant_guest.checkout`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.checkout.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.checkout`); `ui.primary_action` when used; no raw PII | `QA-GUEST-009-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-009` / `[REQUIRED: node-id]` |
| `/checkout/payment` | `GUEST-SCR-010` | Checkout / Payment | `KLUI-GUEST-010` | `customer.checkout.own` | Commerce Store/customer-session read contract `restaurant_guest.checkout.payment`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.checkout.payment.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.checkout_payment`); `ui.primary_action` when used; no raw PII | `QA-GUEST-010-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-010` / `[REQUIRED: node-id]` |
| `/order/:orderId` | `GUEST-SCR-011` | Order / Order detail | `KLUI-GUEST-011` | `customer.order.own` | Commerce Store/customer-session read contract `restaurant_guest.order.detail`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.order.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.order_detail`); `ui.primary_action` when used; no raw PII | `QA-GUEST-011-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-011` / `[REQUIRED: node-id]` |
| `/help` | `GUEST-SCR-012` | Help | `KLUI-GUEST-012` | `public` | Commerce Store/customer-session read contract `restaurant_guest.help`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.help.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.help`); `ui.primary_action` when used; no raw PII | `QA-GUEST-012-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-012` / `[REQUIRED: node-id]` |
| `/status` | `GUEST-SCR-013` | Status | `KLUI-GUEST-013` | `public` | Commerce Store/customer-session read contract `restaurant_guest.status`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | GuestShell; MenuCard; CartSummary; PaymentStatus; OrderProgress; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `restaurant_guest.status.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_guest.status`); `ui.primary_action` when used; no raw PII | `QA-GUEST-013-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-GUEST-013` / `[REQUIRED: node-id]` |

## Required common QA bundles

| Suffix | Minimum verification |
|---|---|
| `-AUTH` | Authentication, permission, resource scope, context mismatch, deep-link and negative-access tests |
| `-STATE` | Loading, valid empty, error, stale, partial, offline, unavailable and route-specific conflict/pending tests |
| `-A11Y` | Keyboard/touch, focus, labels, announcements, contrast, text size and reduced motion |
| `-L10N` | Khmer/English completeness, text expansion, terminology, formatting and missing-key behavior |
| `-RESP` | Supported breakpoints or certified device resolutions, orientation and safe-area behavior |

## Completion evidence

A route can be marked `IMPLEMENTED` only with repository path, component exports, contract tests, permission/RLS tests, visual/accessibility tests, Figma/code reconciliation, deployment evidence and the applicable phase/pilot gate.
