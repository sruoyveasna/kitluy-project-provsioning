# KitLuy Storefront Route and Screen Inventory

| Field | Value |
|---|---|
| Filename | `kitluy-storefront-route-screen-inventory-v1.0.0.md` |
| Version | `v1.0.0` |
| Date | 2026-07-26 |
| Owner | HET / KitLuy Suite Project Owner |
| Status | Canonical target route contract; not implementation evidence |
| Primary market | Cambodia |
| Languages | Khmer (`km-KH`) and English (`en-KH`) |
| Currencies | KHR and USD |
| Timezone | `Asia/Phnom_Penh` |

> **Evidence rule:** This artifact defines a build contract. It is not evidence that Figma files, components, routes, code, migrations, tests or deployments exist. Every missing owner, brand, provider or production value is marked `[REQUIRED: ...]`.

## Authority and scope

Authority order:

1. Current owner decisions and KitLuy Project Instructions.
2. Applied migrations, verified code/tests and production evidence.
3. Current approved KitLuy Rebuild, Business and product specifications.
4. This UI/UX build-pack artifact after approval.
5. Approved handoffs and evidence-based analyses.
6. Competitor rebuild documents as design references only.

The shared design system is neutral. Laundry terminology belongs only in Laundry-specific compositions and must not be hardcoded into Core components.

## Route authority

Routes preserve the current product specification. Where this inventory introduces a Screen ID, analytics namespace or Figma reference, that identifier is a UI traceability addition and does not change product behavior.

## Figma file registry

| Field | Value |
|---|---|
| Product Figma URL | `[REQUIRED: KitLuy Storefront Route and Screen Inventory Figma URL]` |
| Figma file key | `[REQUIRED: file_key]` |
| Design-system library | `[REQUIRED: KitLuy Design System Figma URL]` |
| Screen page | `[REQUIRED: page node-id]` |
| Review status | Not supplied; do not claim Designed/Approved |

## Mapping conventions

- `KLUI-SF-NNN` is a stable UI-pack traceability ID, not a replacement for `KLMF-*` or product feature IDs.
- Permission names are contract requirements; exact registry keys must be reconciled with the canonical RBAC permission registry.
- Data-contract names are families until exact OpenAPI/JSON Schema operation IDs are published.
- Every route implements the canonical state model and must not present stale, partial, cached or unavailable data as authoritative.
- Analytics events never include raw PII, free text, payment tokens or secrets.

## Route and screen inventory

| Route | Screen ID | Screen | Feature IDs | Permission | Data contracts | Mutations | Components | States | Localization keys | Analytics events | QA cases | Figma reference |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `/s/{store_slug}` | `SF-SCR-001` | S / Digital Store | `KLUI-SF-001` | `public` | Commerce Store/customer-session read contract `storefront.s.detail`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.s.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.s_detail`); `ui.primary_action` when used; no raw PII | `QA-SF-001-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-001` / `[REQUIRED: node-id]` |
| `/s/{store_slug}/locations` | `SF-SCR-002` | S / Digital Store / Locations | `KLUI-SF-002` | `public` | Commerce Store/customer-session read contract `storefront.s.detail.locations`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.s.detail.locations.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.s_detail_locations`); `ui.primary_action` when used; no raw PII | `QA-SF-002-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-002` / `[REQUIRED: node-id]` |
| `/s/{store_slug}/l/{location_slug}` | `SF-SCR-003` | S / Digital Store / L / Location | `KLUI-SF-003` | `public` | Commerce Store/customer-session read contract `storefront.s.detail.l.detail`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.s.detail.l.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.s_detail_l_detail`); `ui.primary_action` when used; no raw PII | `QA-SF-003-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-003` / `[REQUIRED: node-id]` |
| `/s/{store_slug}/l/{location_slug}/services` | `SF-SCR-004` | S / Digital Store / L / Location / Services | `KLUI-SF-004` | `public` | Commerce Store/customer-session read contract `storefront.s.detail.l.detail.services`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.s.detail.l.detail.services.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.s_detail_l_detail_services`); `ui.primary_action` when used; no raw PII | `QA-SF-004-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-004` / `[REQUIRED: node-id]` |
| `/s/{store_slug}/l/{location_slug}/prepare` | `SF-SCR-005` | S / Digital Store / L / Location / Prepare | `KLUI-SF-005` | `public` | Commerce Store/customer-session read contract `storefront.s.detail.l.detail.prepare`; `[REQUIRED: schema/version]` | Customer-scoped Commerce/Edge command; token-version and idempotency required | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.s.detail.l.detail.prepare.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.s_detail_l_detail_prepare`); `ui.primary_action` when used; no raw PII | `QA-SF-005-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-005` / `[REQUIRED: node-id]` |
| `/p/{secure_token}` | `SF-SCR-006` | P / Secure customer session | `KLUI-SF-006` | `customer.pre_intake.own` | Commerce Store/customer-session read contract `storefront.p.detail`; `[REQUIRED: schema/version]` | Customer-scoped Commerce/Edge command; token-version and idempotency required | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.p.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.p_detail`); `ui.primary_action` when used; no raw PII | `QA-SF-006-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-006` / `[REQUIRED: node-id]` |
| `/p/{secure_token}/review` | `SF-SCR-007` | P / Secure customer session / Review | `KLUI-SF-007` | `customer.pre_intake.own` | Commerce Store/customer-session read contract `storefront.p.detail.review`; `[REQUIRED: schema/version]` | Customer-scoped Commerce/Edge command; token-version and idempotency required | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.p.detail.review.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.p_detail_review`); `ui.primary_action` when used; no raw PII | `QA-SF-007-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-007` / `[REQUIRED: node-id]` |
| `/p/{secure_token}/check-in` | `SF-SCR-008` | P / Secure customer session / Check In | `KLUI-SF-008` | `customer.pre_intake.own` | Commerce Store/customer-session read contract `storefront.p.detail.check-in`; `[REQUIRED: schema/version]` | Customer-scoped Commerce/Edge command; token-version and idempotency required | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.p.detail.check-in.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.p_detail_check-in`); `ui.primary_action` when used; no raw PII | `QA-SF-008-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-008` / `[REQUIRED: node-id]` |
| `/q/{secure_token}` | `SF-SCR-009` | Q / Secure customer session | `KLUI-SF-009` | `customer.queue.own` | Commerce Store/customer-session read contract `storefront.q.detail`; `[REQUIRED: schema/version]` | Customer-scoped Commerce/Edge command; token-version and idempotency required | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.q.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.q_detail`); `ui.primary_action` when used; no raw PII | `QA-SF-009-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-009` / `[REQUIRED: node-id]` |
| `/c/{secure_token}` | `SF-SCR-010` | C / Secure customer session | `KLUI-SF-010` | `customer.intake_confirmation.own` | Commerce Store/customer-session read contract `storefront.c.detail`; `[REQUIRED: schema/version]` | Customer-scoped Commerce/Edge command; token-version and idempotency required | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.c.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.c_detail`); `ui.primary_action` when used; no raw PII | `QA-SF-010-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-010` / `[REQUIRED: node-id]` |
| `/b/{secure_token}` | `SF-SCR-011` | B / Secure customer session | `KLUI-SF-011` | `customer.booking.own` | Commerce Store/customer-session read contract `storefront.b.detail`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.b.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.b_detail`); `ui.primary_action` when used; no raw PII | `QA-SF-011-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-011` / `[REQUIRED: node-id]` |
| `/telegram` | `SF-SCR-012` | Telegram | `KLUI-SF-012` | `customer.channel.bootstrap` | Commerce Store/customer-session read contract `storefront.telegram`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.telegram.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.telegram`); `ui.primary_action` when used; no raw PII | `QA-SF-012-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-012` / `[REQUIRED: node-id]` |
| `/unavailable` | `SF-SCR-013` | Unavailable | `KLUI-SF-013` | `public` | Commerce Store/customer-session read contract `storefront.unavailable`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.unavailable.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.unavailable`); `ui.primary_action` when used; no raw PII | `QA-SF-013-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-013` / `[REQUIRED: node-id]` |
| `/privacy` | `SF-SCR-014` | Privacy | `KLUI-SF-014` | `public` | Commerce Store/customer-session read contract `storefront.privacy`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.privacy.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.privacy`); `ui.primary_action` when used; no raw PII | `QA-SF-014-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-014` / `[REQUIRED: node-id]` |
| `/terms/intake` | `SF-SCR-015` | Terms / Intake | `KLUI-SF-015` | `public` | Commerce Store/customer-session read contract `storefront.terms.intake`; `[REQUIRED: schema/version]` | None | CustomerShell; StorefrontStatusBanner; LocationContextCard; FreshnessLabel; AccessibleActionPanel | loading, empty, error, stale, partial, offline, unauthorized, unavailable, expired-session, provider-pending, rate-limited | `storefront.terms.intake.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=storefront.terms_intake`); `ui.primary_action` when used; no raw PII | `QA-SF-015-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-SF-015` / `[REQUIRED: node-id]` |

## Required common QA bundles

| Suffix | Minimum verification |
|---|---|
| `-AUTH` | Authentication, permission, resource scope, context mismatch, deep-link and negative-access tests |
| `-STATE` | Loading, valid empty, error, stale, partial, offline, unavailable and route-specific conflict/pending tests |
| `-A11Y` | Keyboard/touch, focus, labels, announcements, contrast, text size and reduced motion |
| `-L10N` | Khmer/English completeness, text expansion, terminology, formatting and missing-key behavior |
| `-RESP` | Supported breakpoints or certified device resolutions, orientation and safe-area behavior |

## Completion evidence

A route can be marked `IMPLEMENTED` only with repository path, component exports, contract tests, permission/RLS tests, visual/accessibility tests, Figma/code reconciliation, deployment evidence and the applicable phase/pilot gate.
