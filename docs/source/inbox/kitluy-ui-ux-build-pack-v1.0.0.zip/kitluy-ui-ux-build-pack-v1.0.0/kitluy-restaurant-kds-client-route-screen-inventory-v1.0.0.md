# KitLuy Restaurant KDS Client Route and Screen Inventory

| Field | Value |
|---|---|
| Filename | `kitluy-restaurant-kds-client-route-screen-inventory-v1.0.0.md` |
| Version | `v1.0.0` |
| Date | 2026-07-26 |
| Owner | HET / KitLuy Suite Project Owner |
| Status | Preliminary phase-gated route contract; not an approved detailed product specification |
| Primary market | Cambodia |
| Languages | Khmer (`km-KH`) and English (`en-KH`) |
| Currencies | KHR and USD |
| Timezone | `Asia/Phnom_Penh` |

> **Evidence rule:** This artifact defines a build contract. It is not evidence that Figma files, components, routes, code, migrations, tests or deployments exist. Every missing owner, brand, provider or production value is marked `[REQUIRED: ...]`.

## Authority and scope

Authority order:

1. Current owner decisions and KitLuy Project Instructions.
2. Applied migrations, verified code/tests and production evidence.
3. Current approved KitLuy Rebuild, Business and product specifications.
4. This UI/UX build-pack artifact after approval.
5. Approved handoffs and evidence-based analyses.
6. Competitor rebuild documents as design references only.

The shared design system is neutral. Laundry terminology belongs only in Laundry-specific compositions and must not be hardcoded into Core components.

## Phase gate

This inventory exists to prevent the application from being omitted from the shared UI/UX pack. It does **not** approve the detailed workflow, schema, state machine, permissions or API contracts. All routes remain hidden and disabled until the Phase product specification, vertical delta, permissions, offline behavior, hardware profile, QA matrix and owner approval exist.

## Figma file registry

| Field | Value |
|---|---|
| Product Figma URL | `[REQUIRED: KitLuy Restaurant KDS Client Route and Screen Inventory Figma URL]` |
| Figma file key | `[REQUIRED: file_key]` |
| Design-system library | `[REQUIRED: KitLuy Design System Figma URL]` |
| Screen page | `[REQUIRED: page node-id]` |
| Review status | Not supplied; do not claim Designed/Approved |

## Mapping conventions

- `KLUI-KDS-NNN` is a stable UI-pack traceability ID, not a replacement for `KLMF-*` or product feature IDs.
- Permission names are contract requirements; exact registry keys must be reconciled with the canonical RBAC permission registry.
- Data-contract names are families until exact OpenAPI/JSON Schema operation IDs are published.
- Every route implements the canonical state model and must not present stale, partial, cached or unavailable data as authoritative.
- Analytics events never include raw PII, free text, payment tokens or secrets.

## Route and screen inventory

| Route | Screen ID | Screen | Feature IDs | Permission | Data contracts | Mutations | Components | States | Localization keys | Analytics events | QA cases | Figma reference |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `/boot` | `KDS-SCR-001` | Boot | `KLUI-KDS-001` | `device.activate` | Management/read-model contract `restaurant_kds.boot`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.boot.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.boot`); `ui.primary_action` when used; no raw PII | `QA-KDS-001-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-001` / `[REQUIRED: node-id]` |
| `/login` | `KDS-SCR-002` | Login | `KLUI-KDS-002` | `restaurant.kds.use` | Management/read-model contract `restaurant_kds.login`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.login.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.login`); `ui.primary_action` when used; no raw PII | `QA-KDS-002-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-002` / `[REQUIRED: node-id]` |
| `/station/select` | `KDS-SCR-003` | Station / Select | `KLUI-KDS-003` | `restaurant.kds.station.select` | Management/read-model contract `restaurant_kds.station.select`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.station.select.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.station_select`); `ui.primary_action` when used; no raw PII | `QA-KDS-003-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-003` / `[REQUIRED: node-id]` |
| `/queue` | `KDS-SCR-004` | Queue | `KLUI-KDS-004` | `restaurant.kds.read` | Management/read-model contract `restaurant_kds.queue`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.queue.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.queue`); `ui.primary_action` when used; no raw PII | `QA-KDS-004-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-004` / `[REQUIRED: node-id]` |
| `/queue/station/:stationId` | `KDS-SCR-005` | Queue / Station / Station detail | `KLUI-KDS-005` | `restaurant.kds.read` | Management/read-model contract `restaurant_kds.queue.station.detail`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.queue.station.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.queue_station_detail`); `ui.primary_action` when used; no raw PII | `QA-KDS-005-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-005` / `[REQUIRED: node-id]` |
| `/ticket/:ticketId` | `KDS-SCR-006` | Ticket / Kitchen ticket detail | `KLUI-KDS-006` | `restaurant.kds.manage` | Management/read-model contract `restaurant_kds.ticket.detail`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.ticket.detail.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.ticket_detail`); `ui.primary_action` when used; no raw PII | `QA-KDS-006-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-006` / `[REQUIRED: node-id]` |
| `/ticket/:ticketId/items` | `KDS-SCR-007` | Ticket / Kitchen ticket detail / Items | `KLUI-KDS-007` | `restaurant.kds.manage` | Management/read-model contract `restaurant_kds.ticket.detail.items`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.ticket.detail.items.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.ticket_detail_items`); `ui.primary_action` when used; no raw PII | `QA-KDS-007-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-007` / `[REQUIRED: node-id]` |
| `/ticket/:ticketId/hold` | `KDS-SCR-008` | Ticket / Kitchen ticket detail / Hold | `KLUI-KDS-008` | `restaurant.kds.manage` | Management/read-model contract `restaurant_kds.ticket.detail.hold`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.ticket.detail.hold.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.ticket_detail_hold`); `ui.primary_action` when used; no raw PII | `QA-KDS-008-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-008` / `[REQUIRED: node-id]` |
| `/ticket/:ticketId/fire` | `KDS-SCR-009` | Ticket / Kitchen ticket detail / Fire | `KLUI-KDS-009` | `restaurant.kds.manage` | Management/read-model contract `restaurant_kds.ticket.detail.fire`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.ticket.detail.fire.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.ticket_detail_fire`); `ui.primary_action` when used; no raw PII | `QA-KDS-009-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-009` / `[REQUIRED: node-id]` |
| `/ticket/:ticketId/complete` | `KDS-SCR-010` | Ticket / Kitchen ticket detail / Complete | `KLUI-KDS-010` | `restaurant.kds.manage` | Management/read-model contract `restaurant_kds.ticket.detail.complete`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.ticket.detail.complete.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.ticket_detail_complete`); `ui.primary_action` when used; no raw PII | `QA-KDS-010-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-010` / `[REQUIRED: node-id]` |
| `/ticket/:ticketId/recall` | `KDS-SCR-011` | Ticket / Kitchen ticket detail / Recall | `KLUI-KDS-011` | `restaurant.kds.manage` | Management/read-model contract `restaurant_kds.ticket.detail.recall`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.ticket.detail.recall.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.ticket_detail_recall`); `ui.primary_action` when used; no raw PII | `QA-KDS-011-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-011` / `[REQUIRED: node-id]` |
| `/history` | `KDS-SCR-012` | History | `KLUI-KDS-012` | `restaurant.kds.history.read` | Management/read-model contract `restaurant_kds.history`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.history.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.history`); `ui.primary_action` when used; no raw PII | `QA-KDS-012-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-012` / `[REQUIRED: node-id]` |
| `/status` | `KDS-SCR-013` | Status | `KLUI-KDS-013` | `restaurant.kds.health.read` | Management/read-model contract `restaurant_kds.status`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.status.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.status`); `ui.primary_action` when used; no raw PII | `QA-KDS-013-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-013` / `[REQUIRED: node-id]` |
| `/settings` | `KDS-SCR-014` | Settings | `KLUI-KDS-014` | `restaurant.kds.settings` | Management/read-model contract `restaurant_kds.settings`; `[REQUIRED: schema/version]` | Phase-gated domain command; `[REQUIRED: approved API operationId/state machine]` | KdsShell; StationHeader; TicketCard; TimerBadge; CourseLane; StateBoundary | loading, empty, error, stale, partial, offline, unauthorized, unavailable, station-offline, ticket-conflict, recalled | `restaurant_kds.settings.*`; shared `state.*`, `action.*`, `a11y.*` | `ui.screen_viewed` (`screen=restaurant_kds.settings`); `ui.primary_action` when used; no raw PII | `QA-KDS-014-AUTH`, `-STATE`, `-A11Y`, `-L10N`, `-RESP` | `FIG-KDS-014` / `[REQUIRED: node-id]` |

## Required common QA bundles

| Suffix | Minimum verification |
|---|---|
| `-AUTH` | Authentication, permission, resource scope, context mismatch, deep-link and negative-access tests |
| `-STATE` | Loading, valid empty, error, stale, partial, offline, unavailable and route-specific conflict/pending tests |
| `-A11Y` | Keyboard/touch, focus, labels, announcements, contrast, text size and reduced motion |
| `-L10N` | Khmer/English completeness, text expansion, terminology, formatting and missing-key behavior |
| `-RESP` | Supported breakpoints or certified device resolutions, orientation and safe-area behavior |

## Completion evidence

A route can be marked `IMPLEMENTED` only with repository path, component exports, contract tests, permission/RLS tests, visual/accessibility tests, Figma/code reconciliation, deployment evidence and the applicable phase/pilot gate.
