# KitLuy Suite RBAC Permission Registry

**Filename:** `kitluy-suite-rbac-permission-registry-v1.0.0.md`  
**Version:** v1.0.0  
**Date:** 2026-07-26  
**Owner:** HET / KitLuy Suite Project Owner  
**Status:** Canonical target contract; not implementation evidence  
**Primary phase:** Phase 1 — Laundry, designed as a shared cross-vertical foundation  
**Locales / currencies / timezone:** Khmer and English; KHR and USD; `Asia/Phnom_Penh`

> **Implementation truth:** This document specifies required behavior. It does not prove that repositories, migrations, tests, deployments, certificates, key stores, or production controls exist. `IMPLEMENTED` requires verified evidence.

## Authority and source baseline

Authority order:

1. Current owner decisions and active KitLuy Project Instructions.
2. Applied migrations, verified code/tests, deployment records, and production evidence.
3. This security and authorization pack.
4. Current KitLuy Rebuild and Business Bibles and approved product specifications.
5. Approved handoffs and registries.
6. Evidence-based competitor analyses and classifications.
7. Competitor clone documents and superseded planning.

Primary source baseline:

- `kitluy-admin-pwa-portal-phase1-spec-v3.1.0.md` — explicit permissions, scopes, environments, A0–A4 approvals, service-identity isolation, access review, support consent, audit, and three-layer enforcement.
- `kitluy-storehub-phase1-spec-v1.0.0.md` — managed-device trust, manufacturing and operational certificates, secure boot, cloned-device defenses, Hub-first provisioning, replacement and recovery.
- `kitluy-ecosystem-infrastructure-phase1-spec-v1.0.0.md` — Supabase/DigitalOcean responsibility split, secret classes, PKI custody, CI/CD, cloud/edge boundaries, and progressive infrastructure controls.
- Current KitLuy Project Instructions — Digital Store authority, Store Hub offline operation, append-only finance/payment/inventory/audit truth, human confirmation for sensitive actions, and no connector direct database access.

## Shared invariants

- Role names organize grants; they are never authoritative by themselves.
- Every privileged request resolves an explicit permission, target resource, resource scope, environment, identity type, validity window, and policy version.
- Missing context fails closed.
- Frontend visibility is not a security boundary. API/worker authorization and Supabase RLS/database rules are mandatory.
- Sensitive finance, permission, compliance, safety, release, migration, device, and production actions require authorized human confirmation according to policy.
- Finalized audit records are append-only; corrections create new events.
- Service accounts and device identities cannot inherit human team membership or interactive login rights.
- No browser, POS client, Storefront, connector, or ordinary operator receives Supabase service-role credentials, CA private keys, release signing keys, or other platform root secrets.
- Store Hub and T1–T4 remain operational offline after provisioning; offline continuity does not weaken identity, permission, custody, payment, or audit requirements.


## 1. Purpose

This registry is the single shared catalogue of action-oriented permission meanings. Products may consume these keys but may not redefine them. A role template is only a versioned bundle of registry keys plus constraints.

## 2. Permission key contract

- Format: `<domain>.<resource_or_capability>.<verb>` or an established shorter action-oriented form.
- Keys are lowercase `snake_case` segments separated by periods.
- A released key is immutable. Changed meaning requires a new key and deprecation link.
- Unknown, disabled, expired, or deprecated-without-compatibility keys fail closed.
- Wildcard grants such as `*`, `admin.*`, or arbitrary prefix matching are prohibited in production.
- Every registry row maps to exactly one primary audit event name. Additional domain events may also be emitted.

## 3. Approval classes

| Class | Required treatment |
|---|---|
| `A0_READ` | Authenticated, scoped read; standard audit according to data class. |
| `A1_STANDARD_MUTATION` | Explicit permission, scope, environment, idempotency, and mutation audit. |
| `A2_REAUTH_MUTATION` | A1 plus fresh approved re-authentication. |
| `A3_FOUR_EYES` | A2 plus independent approver and payload-bound single-use execution authority. |
| `A4_OWNER_SECURITY` | Restricted approver pool, MFA, ticket/incident, alerts, and retrospective review. |

Exact re-authentication ages, approval TTLs, thresholds, and quorum remain `[REQUIRED: approved environment-specific security policy values]`.

## 4. Canonical permission mapping

The `Available scopes` column states the only scope types valid for the permission. The `Environment restrictions` column is restrictive, not descriptive. `Store edge` means an authenticated, provisioned Store Hub or terminal context and does not grant cloud Admin access.

| Permission | Permitted action | Resource type | Available scopes | Environment restrictions | Re-authentication | Approval requirement | Reason requirement | Primary audit event |
|---|---|---|---|---|---|---|---|---|
| `identity.admin_profiles.read` | Read HET Admin eligibility and security state | `admin_user_profile` | platform, region | dev/staging/pilot/prod/dr | No | A0_READ | No | `identity.admin_profile_read` |
| `identity.admin_profiles.manage` | Create, disable, restore, or update an HET Admin profile | `admin_user_profile` | platform | staging/pilot/prod | Yes in pilot/prod | A3_FOUR_EYES | Required | `identity.admin_profile_changed` |
| `identity.sessions.revoke` | Revoke human sessions and refresh tokens | `user_session` | platform, subject | all | Yes in pilot/prod | A2_REAUTH_MUTATION; A3 for bulk | Required | `identity.session_revoked` |
| `identity.mfa.policy_manage` | Change permitted or required MFA policy | `security_policy` | platform | staging/pilot/prod | Yes | A4_OWNER_SECURITY | Required + ticket | `identity.mfa_policy_changed` |
| `identity.break_glass.activate` | Activate incident-bound emergency human access | `break_glass_session` | platform, affected scope | pilot/prod/dr | Yes + MFA | A4_OWNER_SECURITY | Required + incident | `identity.break_glass_activated` |
| `rbac.read` | Read teams, roles, grants, scopes, policies, and effective access | `authorization_config` | platform, region, assigned resources | all | No | A0_READ | No | `rbac.configuration_read` |
| `rbac.team_manage` | Create, version, disable, or rename an HET team | `team` | platform | staging/pilot/prod | Yes in prod | A2_REAUTH_MUTATION | Required | `rbac.team_changed` |
| `rbac.role_manage` | Create or version role templates and custom roles | `role_template` | platform | staging/pilot/prod | Yes | A3_FOUR_EYES for system/broad roles | Required | `rbac.role_template_versioned` |
| `rbac.permission_registry_manage` | Register, deprecate, or replace permission keys | `permission_definition` | platform | staging/pilot/prod | Yes | A4_OWNER_SECURITY | Required + impact assessment | `rbac.permission_registered` |
| `rbac.assignment_manage` | Grant, change, revoke, or extend scoped assignments | `role_assignment` | platform, region, tenant, digital_store, store_location, service | all | Yes in pilot/prod | A2; A3 for high-risk/broad | Required | `rbac.assignment_changed` |
| `rbac.owner_access_manage` | Grant, revoke, or alter platform-owner authority | `role_assignment` | platform | pilot/prod/dr | Yes + MFA | A4_OWNER_SECURITY | Required + ticket | `rbac.owner_access_changed` |
| `rbac.approval_policy_manage` | Version action risk, approver, quorum, reason, and re-auth policy | `approval_policy` | platform | staging/pilot/prod | Yes | A4_OWNER_SECURITY | Required + impact assessment | `rbac.approval_policy_versioned` |
| `rbac.separation_of_duties_manage` | Version conflicting permission and role rules | `sod_policy` | platform | staging/pilot/prod | Yes | A3_FOUR_EYES | Required | `rbac.sod_policy_versioned` |
| `rbac.access_review` | Create, decide, and complete access review campaigns | `access_review` | platform, region, team, environment | all | Yes for final decisions in prod | A2_REAUTH_MUTATION | Required | `rbac.access_review_completed` |
| `rbac.effective_access.explain` | Resolve why a subject is allowed or denied | `authorization_decision` | platform, assigned resources | all | No | A0_READ | No | `rbac.effective_access_explained` |
| `partners.read` | Read Partner/Tenant identity, lifecycle, and verification summary | `tenant` | platform, region, tenant | all | No | A0_READ | No | `partner.read` |
| `partners.verify` | Approve or reject Partner verification evidence | `partner_verification_case` | region, tenant | staging/pilot/prod | Yes in prod | A2_REAUTH_MUTATION | Required | `partner.verification_decided` |
| `partners.suspend` | Restrict or suspend a Partner/Tenant | `tenant` | region, tenant | pilot/prod | Yes | A3_FOUR_EYES | Required + evidence | `partner.suspended` |
| `partners.close` | Close a Partner/Tenant after preservation and legal checks | `tenant` | tenant | prod | Yes + MFA | A4_OWNER_SECURITY | Required + case | `partner.closed` |
| `digital_stores.read` | Read Digital Store configuration, status, and readiness | `digital_store` | tenant, digital_store, region, platform | all | No | A0_READ | No | `digital_store.read` |
| `digital_stores.create` | Create a Digital Store under an authorized Tenant | `digital_store` | tenant | all | No in non-prod; Yes in prod | A1_STANDARD_MUTATION | Required in prod | `digital_store.created` |
| `digital_stores.vertical_lock` | Lock the Digital Store primary vertical | `digital_store` | digital_store | all | Yes after readiness or first transaction | A2_REAUTH_MUTATION | Required | `digital_store.vertical_locked` |
| `digital_stores.activate` | Activate a Digital Store for approved operation | `digital_store` | digital_store | pilot/prod | Yes | A3_FOUR_EYES | Required + readiness evidence | `digital_store.activated` |
| `digital_stores.suspend` | Pause a Digital Store without deleting truth | `digital_store` | digital_store | pilot/prod | Yes | A3_FOUR_EYES | Required | `digital_store.suspended` |
| `locations.read` | Read Store Location identity, readiness, devices, and status | `store_location` | digital_store, store_location, region, platform | all | No | A0_READ | No | `location.read` |
| `locations.create` | Create a physical Store Location under a Digital Store | `store_location` | digital_store | all | No in non-prod; Yes in prod | A1_STANDARD_MUTATION | Required in prod | `location.created` |
| `locations.go_live_request` | Submit a Store Location go-live evidence package | `go_live_request` | store_location | pilot/prod | Yes | A2_REAUTH_MUTATION | Required | `location.go_live_requested` |
| `locations.go_live_approve` | Independently approve physical Store go-live | `store_location` | store_location, region | pilot/prod | Yes | A3_FOUR_EYES | Required + evidence | `location.go_live_approved` |
| `locations.maintenance_toggle` | Enter or leave controlled maintenance mode | `store_location` | store_location | pilot/prod | Yes | A2_REAUTH_MUTATION | Required | `location.maintenance_changed` |
| `locations.decommission` | Decommission a Store Location after data/device reconciliation | `store_location` | store_location | prod | Yes + MFA | A4_OWNER_SECURITY | Required + case | `location.decommissioned` |
| `onboarding.readiness.evaluate` | Run versioned Digital Store or Location readiness checks | `readiness_result` | tenant, digital_store, store_location | all | No | A1_STANDARD_MUTATION | No | `readiness.evaluated` |
| `onboarding.migration.validate` | Run dry-run and validation for data migration | `migration_run` | tenant, digital_store | staging/pilot/prod | Yes in prod | A2_REAUTH_MUTATION | Required in prod | `migration.validation_completed` |
| `onboarding.migration.execute` | Execute approved production migration or cutover | `migration_run` | tenant, digital_store | pilot/prod | Yes | A3_FOUR_EYES | Required + approved plan | `migration.executed` |
| `onboarding.migration.rollback` | Execute approved migration rollback/compensation | `migration_run` | tenant, digital_store | pilot/prod | Yes + MFA | A4_OWNER_SECURITY | Required + incident/change | `migration.rolled_back` |
| `devices.read` | Read device asset, assignment, certificate, health, and version | `device` | tenant, digital_store, store_location, device_group, device, region, platform | all | No | A0_READ | No | `device.read` |
| `devices.register` | Register HET-managed hardware and manufacturing identity | `device` | platform, region | staging/pilot/prod; manufacturing-station context required | Yes | A2_REAUTH_MUTATION | Required | `device.registered` |
| `devices.assign` | Assign a registered device to Tenant, Digital Store, Location, and role | `device_assignment` | tenant, digital_store, store_location, device | all | Yes in pilot/prod | A2_REAUTH_MUTATION | Required | `device.assigned` |
| `devices.certificate.issue` | Issue an operational device certificate | `device_certificate` | device, store_location | pilot/prod | Yes | A3_FOUR_EYES for replacement/CA exceptions | Required | `device.certificate_issued` |
| `devices.certificate.rotate` | Rotate an operational device certificate | `device_certificate` | device | all | Yes in pilot/prod | A2_REAUTH_MUTATION | Required | `device.certificate_rotated` |
| `devices.revoke` | Revoke device certificate, sessions, and queued privileged actions | `device` | device, store_location | pilot/prod | Yes | A3_FOUR_EYES for active Hub | Required + incident/reason | `device.revoked` |
| `devices.identity_replace` | Replace device identity after repair/RMA | `device_identity` | device, store_location | pilot/prod | Yes + MFA | A3_FOUR_EYES | Required + RMA case | `device.identity_replaced` |
| `devices.remote_action.standard` | Queue non-destructive diagnostics/restart/sync action | `device_action` | device, device_group, store_location | pilot/prod | Yes for prod | A2_REAUTH_MUTATION | Required | `device.remote_action_queued` |
| `devices.remote_action.high_risk` | Queue wipe/reset/reprovision/secure erase action | `device_action` | device | pilot/prod | Yes + MFA | A3_FOUR_EYES | Required + evidence | `device.high_risk_action_queued` |
| `fleet.diagnostics.read` | Read device health, logs metadata, and failure summaries | `device_diagnostics` | device, store_location, tenant | all | No | A0_READ | No | `fleet.diagnostics_read` |
| `fleet.logs.request` | Request scoped diagnostic bundle from Hub/device | `diagnostic_bundle` | device, store_location | pilot/prod | Yes | A2_REAUTH_MUTATION | Required + support case | `fleet.diagnostic_bundle_requested` |
| `fleet.sync.trigger` | Request a safe sync/reconciliation cycle | `sync_command` | store_location, device | all | Yes in prod | A2_REAUTH_MUTATION | Required in prod | `fleet.sync_triggered` |
| `releases.read` | Read artifacts, channels, compatibility, rollout, and installations | `release` | platform, region, cohort, device_group | all | No | A0_READ | No | `release.read` |
| `releases.artifact_register` | Register checksum, signature, compatibility, and rollback package | `release_artifact` | platform | staging/pilot/prod registry | Yes | A2_REAUTH_MUTATION | Required | `release.artifact_registered` |
| `releases.rollout_create` | Create or edit an Internal/Pilot/Stable rollout plan | `rollout` | region, cohort, device_group | all | Yes in pilot/prod | A2_REAUTH_MUTATION | Required | `release.rollout_created` |
| `releases.promote_internal` | Promote signed artifact to Internal channel | `release_channel` | platform | development/staging/internal | Yes | A2_REAUTH_MUTATION | Required | `release.promoted_internal` |
| `releases.promote_pilot` | Promote signed artifact to Pilot channel/cohort | `release_channel` | region, cohort | pilot | Yes | A3_FOUR_EYES | Required + test evidence | `release.promoted_pilot` |
| `releases.promote_stable` | Promote signed artifact to Stable | `release_channel` | platform, region | prod | Yes + MFA | A3_FOUR_EYES | Required + pilot evidence | `release.promoted_stable` |
| `releases.pause` | Pause an active rollout | `rollout` | region, cohort | pilot/prod | Yes | A2; A3 for broad Stable | Required | `release.rollout_paused` |
| `releases.rollback` | Rollback active rollout or affected cohort | `rollout` | region, cohort, device_group | pilot/prod | Yes | A3_FOUR_EYES; A4 if platform-wide | Required + incident/evidence | `release.rolled_back` |
| `configuration.read` | Read desired, published, acknowledged, and active configuration | `configuration_version` | tenant, digital_store, store_location, channel | all | No | A0_READ | No | `configuration.read` |
| `configuration.publish` | Publish immutable configuration version to approved targets | `configuration_publication` | digital_store, store_location, channel | all | Yes in pilot/prod | A2; A3 for broad production | Required | `configuration.published` |
| `configuration.rollback` | Publish a prior compatible configuration version | `configuration_publication` | digital_store, store_location, channel | pilot/prod | Yes | A3_FOUR_EYES | Required | `configuration.rolled_back` |
| `platform.health.read` | Read cloud/service/job/provider health with freshness | `platform_component` | platform, region, service | all | No | A0_READ | No | `platform.health_read` |
| `platform.jobs.retry` | Retry an eligible idempotent job | `durable_job` | service, tenant, store_location | all | Yes in prod | A2_REAUTH_MUTATION | Required | `job.retry_requested` |
| `platform.jobs.dead_letter_manage` | Requeue, cancel, or quarantine dead-letter work | `durable_job` | service, tenant, store_location | pilot/prod | Yes | A3_FOUR_EYES for finance/device/release jobs | Required | `job.dead_letter_changed` |
| `platform.incident.declare` | Declare or change incident severity and command state | `incident` | platform, region, service, tenant | all | Yes in prod | A2_REAUTH_MUTATION | Required | `incident.declared` |
| `platform.safety_switch.toggle` | Toggle narrowly scoped safety control | `safety_switch` | platform, service, connector, cohort | pilot/prod | Yes + MFA | A3_FOUR_EYES; A4 platform-wide | Required + incident/change | `platform.safety_switch_changed` |
| `platform.backup.restore_test` | Run non-production restore verification | `backup_restore` | service, environment | development/staging/dr | Yes | A2_REAUTH_MUTATION | Required | `backup.restore_tested` |
| `platform.backup.restore_production` | Restore or fail over production data/service | `backup_restore` | platform, service, region | prod/dr | Yes + MFA | A4_OWNER_SECURITY | Required + incident | `backup.production_restore_started` |
| `billing.read` | Read plans, entitlements, subscriptions, invoices, and attempts | `billing_record` | tenant, digital_store, platform | all | No | A0_READ | No | `billing.read` |
| `billing.invoice_adjust` | Create compensating adjustment or credit proposal | `invoice_adjustment` | tenant, invoice | pilot/prod | Yes | A3_FOUR_EYES above policy threshold | Required | `billing.invoice_adjustment_created` |
| `billing.invoice_mark_paid` | Record approved manual settlement evidence | `invoice` | tenant, invoice | prod | Yes | A3_FOUR_EYES | Required + evidence | `billing.invoice_marked_paid` |
| `billing.grace_change` | Change subscription grace/restriction window | `subscription` | tenant, digital_store | pilot/prod | Yes | A2_REAUTH_MUTATION | Required | `billing.grace_changed` |
| `billing.policy_manage` | Version plan, entitlement, dunning, or billing policy | `billing_policy` | platform | staging/pilot/prod | Yes + MFA | A4_OWNER_SECURITY | Required + impact assessment | `billing.policy_versioned` |
| `support.ticket.manage` | Create, assign, escalate, resolve, or reopen support ticket | `support_ticket` | tenant, digital_store, store_location, device | all | No for routine; Yes for sensitive changes | A1_STANDARD_MUTATION | Required for escalation/closure | `support.ticket_changed` |
| `support.evidence.read` | Read support-authorized evidence for a case | `support_evidence` | consent_session scope | pilot/prod | Yes for sensitive data | A2_REAUTH_MUTATION | Required + active consent | `support.evidence_viewed` |
| `support.consent_session.start` | Start a Partner-consented support access session | `support_access_session` | tenant, digital_store, store_location, device | pilot/prod | Yes | A3_FOUR_EYES for impersonation/write | Required + ticket + consent | `support.consent_session_started` |
| `support.impersonation.start` | Enter a clearly marked, scoped impersonation/session view | `support_access_session` | tenant, digital_store, store_location | pilot/prod | Yes + MFA | A3_FOUR_EYES | Required + explicit consent | `support.impersonation_started` |
| `support.intervention.execute` | Perform an approved support intervention | `support_intervention` | active consent session scope | pilot/prod | Yes | Policy-derived A2/A3 | Required | `support.intervention_recorded` |
| `support.session.revoke` | End support access immediately | `support_access_session` | tenant, session | pilot/prod | No for Partner owner; Yes for HET | A1_STANDARD_MUTATION | Required | `support.consent_session_revoked` |
| `integrations.read` | Read connector configuration, scopes, status, and health | `connector` | tenant, digital_store, connector, platform | all | No | A0_READ | No | `integration.read` |
| `integrations.test` | Run governed sandbox/health test | `connector_test` | connector, tenant, digital_store | all | Yes in prod | A2_REAUTH_MUTATION | Required in prod | `integration.test_run` |
| `integrations.credentials_rotate` | Rotate connector/provider credential reference | `connector_credential` | connector | pilot/prod | Yes + MFA | A3_FOUR_EYES for payment/production | Required | `integration.credential_rotated` |
| `integrations.production_enable` | Enable connector for production data flow | `connector` | connector, tenant, digital_store | prod | Yes + MFA | A3_FOUR_EYES | Required + certification | `integration.production_enabled` |
| `integrations.suspend` | Suspend connector data flow safely | `connector` | connector, tenant, digital_store | pilot/prod | Yes | A2; A3 if broad | Required | `integration.suspended` |
| `webhooks.replay` | Replay an eligible signed webhook delivery | `webhook_delivery` | connector, tenant, digital_store | all | Yes in prod | A2_REAUTH_MUTATION | Required | `webhook.replay_requested` |
| `audit.read` | Read immutable audit and authorization events | `audit_event` | platform, region, tenant, digital_store, store_location, subject | all | No | A0_READ | No | `audit.read` |
| `audit.export` | Create scoped, checksummed audit evidence package | `audit_export` | authorized scope | all | Yes in prod | A2_REAUTH_MUTATION | Required | `audit.export_requested` |
| `audit.security_review` | Record security-control or incident-review decision | `security_review` | platform, region, incident, subject | pilot/prod | Yes | A2_REAUTH_MUTATION | Required | `audit.security_review_recorded` |
| `files.read` | Read authorized file metadata and obtain short-lived signed access | `file_object` | tenant, digital_store, store_location, support session | all | No; Yes for sensitive | A0/A2 by class | Policy-derived | `file.access_issued` |
| `files.security_export` | Export sensitive security, certificate, or audit evidence | `file_export` | authorized scope | pilot/prod | Yes | A3_FOUR_EYES for broad/high sensitivity | Required | `file.security_export_created` |
| `reports.export` | Generate operational/report export without commercial paywall | `report_export` | tenant, digital_store, store_location | all | No; Yes for sensitive/bulk | A1/A2 by class | Required for sensitive/bulk | `report.export_requested` |
| `ai.policies.read` | Read AI Gateway, RAG, MCP, and model policy | `ai_policy` | platform, service | all | No | A0_READ | No | `ai.policy_read` |
| `ai.policies.manage` | Version model routing, data, retention, or tool policy | `ai_policy` | platform, service | staging/pilot/prod | Yes | A3_FOUR_EYES | Required + evaluation evidence | `ai.policy_versioned` |
| `ai.rag_sources.manage` | Add, disable, or reindex approved RAG source | `rag_source` | platform, tenant, knowledge_base | all | Yes in prod | A2_REAUTH_MUTATION | Required | `ai.rag_source_changed` |
| `ai.mcp_tools.enable_read` | Enable read-only MCP tool in approved scope | `mcp_tool` | platform, service, tenant | staging/pilot/prod | Yes | A3_FOUR_EYES in prod | Required + evaluation | `ai.mcp_tool_enabled` |
| `ai.mcp_tools.enable_write` | Enable write-capable MCP tool | `mcp_tool` | platform, service, tenant | pilot/prod | Yes + MFA | A4_OWNER_SECURITY | Required + security review | `ai.write_tool_enabled` |
| `laundry.bookings.read` | Read Laundry Booking and custody status | `laundry_booking` | tenant, digital_store, store_location | all | No | A0_READ | No | `laundry.booking_read` |
| `laundry.bookings.create` | Create authoritative Laundry Booking at T1/approved channel | `laundry_booking` | store_location, terminal_role:T1 | store_edge/pilot/prod | User PIN/session per role | A1_STANDARD_MUTATION | Operational reason only for override | `laundry.booking_created` |
| `laundry.bookings.price_override` | Override calculated price before finalization | `laundry_booking` | store_location, terminal_role:T1 | store_edge/pilot/prod | Yes/PIN | A2_REAUTH_MUTATION | Required | `laundry.price_overridden` |
| `laundry.ready_scan_in` | Record T3 Clean & Ready custody scan-in | `garment_custody` | store_location, terminal_role:T3 | store_edge/pilot/prod | Role session | A1_STANDARD_MUTATION | Required for exception | `garment.ready_scanned_in` |
| `laundry.pickup_scan_out` | Record T4 customer pickup and custody release | `garment_custody` | store_location, terminal_role:T4 | store_edge/pilot/prod | Role session; supervisor for override | A2 for exception | Required for override | `garment.pickup_scanned_out` |
| `laundry.booking.complete` | Complete Booking after payment/custody conditions | `laundry_booking` | store_location, terminal_role:T4 | store_edge/pilot/prod | Role session | A1; A2 exception | Required for exception | `laundry.booking_completed` |
| `payments.read` | Read payment state, provider reference, and reconciliation summary | `payment` | tenant, digital_store, store_location | all | No | A0_READ | No | `payment.read` |
| `payments.capture.cash` | Record cash tender at authorized T1/T4 workflow | `payment` | store_location, terminal_role:T1/T4 | store_edge/pilot/prod | Role session | A1_STANDARD_MUTATION | No except override | `payment.cash_recorded` |
| `payments.khqr.create` | Create KHQR payment request through approved adapter | `payment_request` | store_location, terminal_role:T1/T4, storefront | store_edge/pilot/prod | Role/session as applicable | A1_STANDARD_MUTATION | No | `payment.khqr_requested` |
| `payments.refund.request` | Request compensating refund | `refund_request` | tenant, digital_store, store_location, payment | pilot/prod | Yes/PIN | A2_REAUTH_MUTATION | Required | `payment.refund_requested` |
| `payments.refund.approve` | Approve refund under threshold/policy | `refund_request` | store_location, tenant | pilot/prod | Yes/PIN | A3_FOUR_EYES above threshold | Required | `payment.refund_approved` |
| `payments.void.request` | Request void before settlement/finalization under rules | `void_request` | store_location, transaction | store_edge/pilot/prod | Yes/PIN | A2_REAUTH_MUTATION | Required | `payment.void_requested` |
| `inventory.movements.read` | Read append-only inventory/consumable movement ledger | `inventory_movement` | tenant, digital_store, store_location | all | No | A0_READ | No | `inventory.movement_read` |
| `inventory.adjustment.request` | Request inventory/consumable correction | `inventory_adjustment` | store_location, item | store_edge/pilot/prod | Yes/PIN | A2_REAUTH_MUTATION | Required | `inventory.adjustment_requested` |
| `inventory.adjustment.approve` | Approve material inventory correction | `inventory_adjustment` | store_location, tenant | pilot/prod | Yes | A3_FOUR_EYES above threshold | Required | `inventory.adjustment_approved` |

## 5. Product consumption rules

1. A product requests a permission key; it does not infer authority from a role label, route, team, or UI component.
2. Product-specific permissions must be proposed through a registry change with owner, domain, action, resource, scope, environment, risk, audit, and backward-compatibility analysis.
3. Partner, Chain, Store staff, HET Admin, machine, connector, and device subjects use the same permission vocabulary where the action meaning is identical, but their eligible scopes and identity policies differ.
4. HET Admin platform scope does not automatically grant Store operational actions such as Booking creation, customer payment, garment release, or finalized record mutation.
5. T1–T4 terminal-role restrictions are enforced in the Edge authorization context and append-only custody/payment rules.
6. Reports, exports, and history cannot be commercially paywalled; access still requires permission, scope, privacy, security, and fair-use controls.

## 6. Registration schema

Minimum relational fields for `kitluy_auth.permissions`:

```text
id uuid
permission_key text unique
version integer
status active|deprecated|disabled
name_i18n reference
purpose text
resource_type text
risk_class A0|A1|A2|A3|A4
allowed_scope_types[] reference or relation
allowed_environments[] reference or relation
requires_reauthentication boolean/policy_ref
approval_policy_ref uuid
reason_policy_ref uuid
audit_event_key text
deprecated_by_permission_id uuid null
effective_at timestamptz
retired_at timestamptz null
created_by_subject_id uuid
created_at timestamptz
```

Arrays may be normalized into join tables; JSON must not become the primary authority.

## 7. Change and deprecation

- Additive new permission: normal versioned registry change.
- Narrowing a permission: new registry version, impact preview, migration, and access review.
- Broadening a permission: new key or explicit owner-approved breaking change; never silent.
- Deprecation: continue compatibility only for a defined window; log every use; provide replacement key.
- Deletion: prohibited while referenced by assignments, role versions, policies, audit, or historical evidence.

## 8. Contract tests

- Every API/worker/Edge mutation maps to a registered active permission.
- Every registered mutation permission maps to an audit event.
- Every permission has valid resource, scope, and environment references.
- No role template grants an unknown key.
- No production role contains wildcard permission grants.
- Permission deprecation does not change historical authorization reconstruction.
- Negative tests prove team membership, role name, UI visibility, client metadata, and service-role credentials alone cannot authorize an action.

## Appendix A — Reserved future namespaces

Reserved without Phase 1 activation: `restaurant.*`, `ecommerce.*`, `convenience.*`, `pharmacy.*`, `department_store.*`, `grocery.*`, and `supermarket.*`. Each later vertical must reuse shared permissions first and add only genuine vertical deltas.
