# KitLuy Security and Authorization Pack v1.0.0

Date: 2026-07-26

This directory contains the ten canonical documents requested for the shared Phase 1 security and authorization foundation:

1. `kitluy-suite-rbac-permission-registry-v1.0.0.md`
2. `kitluy-resource-scope-model-v1.0.0.md`
3. `kitluy-sensitive-action-and-four-eyes-policy-v1.0.0.md`
4. `kitluy-audit-event-registry-v1.0.0.md`
5. `kitluy-service-account-and-machine-identity-policy-v1.0.0.md`
6. `kitluy-device-certificate-and-trust-policy-v1.0.0.md`
7. `kitluy-support-access-and-consent-policy-v1.0.0.md`
8. `kitluy-secrets-and-key-management-policy-v1.0.0.md`
9. `kitluy-threat-model-phase1-v1.0.0.md`
10. `kitluy-security-test-plan-phase1-v1.0.0.md`

All files are target contracts and do not claim implementation. Exact deployment/security values not established by current owner sources remain marked `[REQUIRED: ...]`.
